#include<stdio.h>
int main()
{
int i;
char *p[3]={"good", "morning","friends"};
for(i=0;i<3;i++)
	printf("%s\n",p[i]);

}
